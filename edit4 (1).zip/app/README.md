# iManagerV1

# Hello! Welcome to iManager V1, We are working hard on the bot and we can't wait for you to see what we have ready for you.

# The old BOT Owner Was billy now it is managed by IvRxin, Noah, Tiger. 

# If you are found with this code, and you have not paid for the BOT, please remove the 'app' folder now!

# Thanks for using iManager V1! Hope to see you in V2!
